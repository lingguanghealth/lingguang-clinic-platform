import './styles/base.css';
import './styles/components.css';
import './styles/responsive.css';
import { createAppShell } from './shell.js';
import { router } from './router.js';
import { seedIfEmpty } from './services/store.js';

seedIfEmpty();
document.querySelector('#app').innerHTML = createAppShell();
router.start();
