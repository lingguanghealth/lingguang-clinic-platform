export const hero = (title, text, actions='') => `<div class="hero"><div><h2>${title}</h2><p>${text}</p></div>${actions}</div>`;
export const empty = text => `<div class="empty-state">${text}</div>`;
export const badge = (text, tone='default') => `<span class="badge ${tone}">${text}</span>`;
