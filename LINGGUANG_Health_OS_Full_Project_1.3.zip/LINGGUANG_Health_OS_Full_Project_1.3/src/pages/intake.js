import { hero } from './shared.js';
import { intakeView } from '../modules/intake/intakeView.js';
import { draft, step, setStep, updateDraft, toggleConcern, resetIntake } from '../modules/intake/intakeState.js';
import { makeSummary, makeTcmSummary, detectRisks } from '../modules/intake/intakeEngine.js';
import { readStore, updateStore } from '../services/store.js';
import { toast } from '../services/ui.js';
import { router } from '../router.js';

function capture(){const value=id=>document.querySelector(`#${id}`)?.value;const maps=[['firstName','lastName','dob','gender','phone','email'],['notes'],['painLocation','painScore','duration','sleepImpact','redFlags'],['sleepScore','energyScore','coldHeat','digestion','stressScore']];if(step<4){const values={};maps[step].forEach(k=>values[k]=value(k));updateDraft(values);}}
function rerender(){document.querySelector('#intake-content').innerHTML=intakeView();mountControls();}
function mountControls(){document.querySelectorAll('[data-concern]').forEach(b=>b.onclick=()=>{toggleConcern(b.dataset.concern);rerender();});document.querySelector('[data-intake-back]')?.addEventListener('click',()=>{capture();setStep(step-1);rerender();});document.querySelector('[data-intake-next]')?.addEventListener('click',()=>{capture();if(step===0&&(!draft.firstName||!draft.lastName||!draft.phone))return toast('First name, last name and phone are required');if(step===1&&!(draft.concerns||[]).length)return toast('Select at least one concern');if(step<4){setStep(step+1);rerender();return;}submit();});}
function submit(){const d={...draft};const name=`${d.firstName} ${d.lastName}`.trim();updateStore(store=>{let patient=store.patients.find(p=>p.name.toLowerCase()===name.toLowerCase());if(!patient){patient={id:crypto.randomUUID(),name,phone:d.phone,email:d.email,primaryConcern:(d.concerns||[]).join(', ')};store.patients.push(patient);}store.intakes.push({id:crypto.randomUUID(),patientId:patient.id,patientName:name,concerns:d.concerns||[],summary:makeSummary(d),tcmSummary:makeTcmSummary(d),risks:detectRisks(d),raw:d,createdAt:new Date().toISOString()});});resetIntake();toast('Assessment submitted');router.go('clinical-summary');}
export async function intakePage(){return{title:'AI Intake',subtitle:'Patient health assessment',html:`${hero('Patient Health Assessment','Classic structured intake inside the main LINGGUANG system.')}<div id="intake-content">${intakeView()}</div>`,mount:mountControls};}
