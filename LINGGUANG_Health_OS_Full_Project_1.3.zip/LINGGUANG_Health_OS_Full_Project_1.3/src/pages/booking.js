import { readStore, updateStore } from '../services/store.js';
import { toast, escapeHtml, formatDate } from '../services/ui.js';
import { hero, empty, badge } from './shared.js';
export async function bookingPage() {
  const d = readStore();
  return { title:'Booking', subtitle:'Smart booking and appointment requests', html:`
    ${hero('Smart Booking','Create, confirm, and manage appointment requests.')}
    <div class="panel"><form id="booking-form" class="form-grid">
      <label>Patient Name<input name="patientName" required></label><label>Date<input type="date" name="date" required></label>
      <label>Time<input type="time" name="time" required></label><label>Service<select name="service"><option>Follow-up Acupuncture</option><option>Initial Consultation</option><option>Pain Assessment</option><option>Wellness Consultation</option></select></label>
      <label>Status<select name="status"><option>Pending</option><option>Confirmed</option></select></label><div class="form-action"><button class="button primary">Save Appointment</button></div>
    </form></div>
    <div class="panel"><div class="panel-head"><h3>Appointments</h3><span>${d.appointments.length}</span></div><div id="appointment-list">
    ${d.appointments.length ? `<table><thead><tr><th>Patient</th><th>Date</th><th>Service</th><th>Status</th><th></th></tr></thead><tbody>${d.appointments.map(x=>`<tr><td>${escapeHtml(x.patientName)}</td><td>${formatDate(x.date)} ${escapeHtml(x.time)}</td><td>${escapeHtml(x.service)}</td><td>${badge(x.status,x.status==='Pending'?'warning':'default')}</td><td><button class="button mini secondary" data-toggle-appointment="${x.id}">Toggle</button><button class="button mini danger" data-delete-appointment="${x.id}">Delete</button></td></tr>`).join('')}</tbody></table>` : empty('No appointments saved.')}</div></div>`,
    mount(){
      document.querySelector('#booking-form').addEventListener('submit',e=>{e.preventDefault();const v=Object.fromEntries(new FormData(e.currentTarget));updateStore(d=>d.appointments.push({id:crypto.randomUUID(),...v}));toast('Appointment saved');bookingPage().then(p=>{document.querySelector('#page-root').innerHTML=p.html;p.mount();});});
      document.querySelectorAll('[data-toggle-appointment]').forEach(b=>b.onclick=()=>{updateStore(d=>{const x=d.appointments.find(x=>x.id===b.dataset.toggleAppointment);x.status=x.status==='Pending'?'Confirmed':'Pending';});location.reload();});
      document.querySelectorAll('[data-delete-appointment]').forEach(b=>b.onclick=()=>{updateStore(d=>d.appointments=d.appointments.filter(x=>x.id!==b.dataset.deleteAppointment));location.reload();});
    }
  };
}
