import { readStore } from '../services/store.js';
import { hero, badge, empty } from './shared.js';
import { formatDate, escapeHtml } from '../services/ui.js';
export async function todayPage() {
  const d = readStore();
  const openFollowups = d.followups.filter(x => !x.done);
  const schedule = d.appointments.slice().sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
  return { title:'Today', subtitle:'Practitioner workspace', html:`
    ${hero('Good evening, Dr. Ling.','Here is what needs your attention today.')}
    <div class="stats-grid">
      <div class="stat-card"><span>Patients</span><strong>${d.patients.length}</strong><small>Active local records</small></div>
      <div class="stat-card"><span>Pending Requests</span><strong>${d.appointments.filter(x=>x.status==='Pending').length}</strong><small>Awaiting review</small></div>
      <div class="stat-card"><span>AI Summaries</span><strong>${d.intakes.length}</strong><small>Available for review</small></div>
      <div class="stat-card"><span>Follow-up Tasks</span><strong>${openFollowups.length}</strong><small>Open tasks</small></div>
    </div>
    <div class="two-panel">
      <div class="panel"><div class="panel-head"><h3>Today's Schedule</h3><button class="button secondary" data-route="booking">Add</button></div>
      ${schedule.length ? schedule.map(x=>`<div class="list-row"><b>${escapeHtml(x.time)}</b><div><strong>${escapeHtml(x.patientName)}</strong><small>${escapeHtml(x.service)} · ${formatDate(x.date)}</small></div>${badge(x.status,x.status==='Pending'?'warning':'default')}</div>`).join('') : empty('No appointments yet.')}</div>
      <div class="panel"><div class="panel-head"><h3>Priorities</h3></div>
      ${d.intakes.slice(-2).map(i=>`<div class="list-row"><b>AI</b><div><strong>Review ${escapeHtml(i.patientName)}</strong><small>${escapeHtml(i.concerns.join(', '))}</small></div>${badge('Review','warning')}</div>`).join('') || empty('No priority tasks.')}
      </div>
    </div>` };
}
