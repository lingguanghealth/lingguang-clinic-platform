import { readDraft, writeDraft, clearDraft } from '../../services/store.js';
export let step=0;
export let draft=readDraft();
export function setStep(value){step=Math.max(0,Math.min(4,value));}
export function updateDraft(values){draft={...draft,...values};writeDraft(draft);}
export function toggleConcern(value){const s=new Set(draft.concerns||[]);s.has(value)?s.delete(value):s.add(value);updateDraft({concerns:[...s]});}
export function resetIntake(){step=0;draft={};clearDraft();}
