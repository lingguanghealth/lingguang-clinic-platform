const KEY = 'lingguang-health-os-v1.3';
const DRAFT_KEY = 'lingguang-intake-draft-v1.3';

const initial = {
  patients: [], appointments: [], intakes: [], clinicalNotes: [], checkins: [], followups: [], riskReviews: []
};

export function readStore() {
  try { return JSON.parse(localStorage.getItem(KEY)) || structuredClone(initial); }
  catch { return structuredClone(initial); }
}
export function writeStore(data) { localStorage.setItem(KEY, JSON.stringify(data)); window.dispatchEvent(new Event('lingguang:data')); }
export function updateStore(mutator) { const data = readStore(); mutator(data); writeStore(data); return data; }
export function resetStore() { writeStore(structuredClone(initial)); localStorage.removeItem(DRAFT_KEY); }
export function readDraft() { try { return JSON.parse(localStorage.getItem(DRAFT_KEY)) || {}; } catch { return {}; } }
export function writeDraft(draft) { localStorage.setItem(DRAFT_KEY, JSON.stringify(draft)); }
export function clearDraft() { localStorage.removeItem(DRAFT_KEY); }
export function seedIfEmpty() {
  if (localStorage.getItem(KEY)) return;
  const data = structuredClone(initial);
  data.appointments = [
    { id: crypto.randomUUID(), patientName: 'John Smith', date: new Date().toISOString().slice(0,10), time: '09:00', service: 'Follow-up Acupuncture', status: 'Confirmed' },
    { id: crypto.randomUUID(), patientName: 'Emily Johnson', date: new Date().toISOString().slice(0,10), time: '10:30', service: 'Initial Consultation', status: 'Pending' }
  ];
  writeStore(data);
}
