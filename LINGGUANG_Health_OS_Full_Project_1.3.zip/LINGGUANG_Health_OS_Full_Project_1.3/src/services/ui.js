export function toast(message) {
  const el = document.querySelector('#toast');
  el.textContent = message; el.classList.add('show');
  clearTimeout(window.__toastTimer); window.__toastTimer = setTimeout(() => el.classList.remove('show'), 1800);
}
export function openModal(html) {
  const modal = document.querySelector('#modal');
  document.querySelector('#modal-card').innerHTML = html;
  modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false');
}
export function closeModal() {
  const modal = document.querySelector('#modal'); modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true');
}
export function escapeHtml(value='') { return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
export function formatDate(value) { if (!value) return '—'; return new Date(`${value}T12:00:00`).toLocaleDateString('en-CA', { month:'short', day:'numeric', year:'numeric' }); }
