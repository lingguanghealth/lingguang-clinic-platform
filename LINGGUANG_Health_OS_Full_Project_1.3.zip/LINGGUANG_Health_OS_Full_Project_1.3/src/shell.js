export function createAppShell() {
  return `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand">
          <div class="brand-logo">LG</div>
          <div><strong>LINGGUANG</strong><small>Health OS</small></div>
        </div>
        <nav class="main-nav" aria-label="Main navigation">
          <button data-route="today">🏠 Today</button>
          <button data-route="booking">📅 Booking</button>
          <button data-route="patients">👥 Patients</button>
          <button data-route="clinical">🩺 Clinical</button>
          <button data-route="ai-care">🤖 AI Care</button>
          <button data-route="health-journey">📈 Health Journey</button>
          <button data-route="clinic">🏥 Clinic</button>
        </nav>
        <div class="build-label">Full Project 1.3</div>
      </aside>
      <main class="workspace">
        <header class="workspace-header">
          <div><h1 id="page-title"></h1><p id="page-subtitle"></p></div>
          <div class="avatar">DL</div>
        </header>
        <section id="page-root" aria-live="polite"></section>
      </main>
    </div>
    <div class="toast" id="toast"></div>
    <div class="modal" id="modal" aria-hidden="true"><div class="modal-card" id="modal-card"></div></div>
  `;
}
