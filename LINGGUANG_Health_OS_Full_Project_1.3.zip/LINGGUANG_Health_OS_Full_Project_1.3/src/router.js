import { todayPage } from './pages/today.js';
import { bookingPage } from './pages/booking.js';
import { patientsPage } from './pages/patients.js';
import { clinicalPage } from './pages/clinical.js';
import { aiCarePage } from './pages/aiCare.js';
import { intakePage } from './pages/intake.js';
import { clinicalSummaryPage } from './pages/clinicalSummary.js';
import { healthAnalysisPage } from './pages/healthAnalysis.js';
import { remoteCarePage } from './pages/remoteCare.js';
import { followUpPage } from './pages/followUp.js';
import { riskReviewPage } from './pages/riskReview.js';
import { healthJourneyPage } from './pages/healthJourney.js';
import { clinicPage } from './pages/clinic.js';

const routes = {
  today: todayPage,
  booking: bookingPage,
  patients: patientsPage,
  clinical: clinicalPage,
  'ai-care': aiCarePage,
  intake: intakePage,
  'clinical-summary': clinicalSummaryPage,
  'health-analysis': healthAnalysisPage,
  'remote-care': remoteCarePage,
  'follow-up': followUpPage,
  'risk-review': riskReviewPage,
  'health-journey': healthJourneyPage,
  clinic: clinicPage
};

function currentRoute() {
  return location.hash.replace('#/', '') || 'today';
}

async function render() {
  const route = currentRoute();
  const page = routes[route] || routes.today;
  const result = await page();
  document.querySelector('#page-title').textContent = result.title;
  document.querySelector('#page-subtitle').textContent = result.subtitle;
  document.querySelector('#page-root').innerHTML = result.html;
  document.querySelectorAll('[data-route]').forEach(btn => btn.classList.toggle('active', btn.dataset.route === route));
  result.mount?.();
  window.scrollTo({ top: 0, behavior: 'instant' });
}

export const router = {
  start() {
    document.addEventListener('click', event => {
      const trigger = event.target.closest('[data-route]');
      if (trigger) location.hash = `#/${trigger.dataset.route}`;
    });
    addEventListener('hashchange', render);
    render();
  },
  go(route) { location.hash = `#/${route}`; }
};
